#include <stdio.h>
#include "lib.h"

int		main(void)
{
	printf("\n********EJERCICIO 00********* \n");
	ft_putchar('@');

	printf("\n********EJERCICIO 01********* \n");
	ft_print_alphabet();
	printf("\n********EJERCICIO 02********* \n");
	ft_print_reverse_alphabet();
	printf("\n********EJERCICIO 03********* \n");
	ft_print_numbers();
	printf("\n********EJERCICIO 04******** \n");
	ft_is_negative(33);
	printf("\n********EJERCICIO 05*********\n");
	ft_print_comb();
	printf("\nEJERCICIO 06*********\n");
	ft_print_comb2();
	printf("\n********EJERCICIO 07********\n");
	ft_putnbr(42);
	printf("\n********EJERCICIO 08********\n");
	ft_print_combn(2);
	printf("\n");
}
